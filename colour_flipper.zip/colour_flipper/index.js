function color_generator (){
    var r = Math.floor(Math.random() * 256);
    var g = Math.floor(Math.random() * 256);
    var b = Math.floor(Math.random() * 256);
    $('body').css({
        'background-color': 'rgb(' + r + ',' + g + ',' + b + ')'
        
    });
    var rbg = `RGB(${r},${g},${b})`
    $('h3').text(rbg);
}

$('#flip').click(color_generator);
